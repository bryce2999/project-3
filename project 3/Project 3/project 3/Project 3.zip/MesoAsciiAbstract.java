public abstract class MesoAsciiAbstract
{
	abstract int calAverage();
}