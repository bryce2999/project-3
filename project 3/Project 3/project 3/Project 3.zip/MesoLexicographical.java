
public class MesoLexicographical extends MesoSortedAbstract
{

}